<?php

return [
    'name' => 'Logs'
];
