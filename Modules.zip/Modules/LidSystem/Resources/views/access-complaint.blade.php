@extends('lidsystem::layouts.master')

@section('content')
<div class="container">
    <hr>
    <h3>Жалоба отправлена</h3>

</div>

@endsection
