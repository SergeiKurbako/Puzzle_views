
    <div class="container">
        <hr>
        Спасибо за регистрацию
        <a href="/gameframe/{{$frameId}}?&code={{$code}}&lid_id={{$lidId}}">Начать игру</a>
    </div>
