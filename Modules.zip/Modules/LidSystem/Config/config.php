<?php

return [
    'name' => 'LidSystem'
];
