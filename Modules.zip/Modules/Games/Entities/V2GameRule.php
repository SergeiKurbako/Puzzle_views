<?php

namespace Modules\Games\Entities;

use Illuminate\Database\Eloquent\Model;

class V2GameRule extends Model
{
    protected $fillable = [];
}
