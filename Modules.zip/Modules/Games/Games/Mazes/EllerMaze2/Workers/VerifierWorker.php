<?php

namespace Modules\Games\Games\Mazes\EllerMaze2\Workers;

use Avior\GameCore\Workers\Worker;
use Avior\GameCore\Base\IToolsPool;
use Avior\GameCore\Base\IDataPool;

class VerifierWorker extends Worker
{
    public function verificationOpenGameRequest(IDataPool $dataPool, IToolsPool $toolsPool)
    {

    }
}
