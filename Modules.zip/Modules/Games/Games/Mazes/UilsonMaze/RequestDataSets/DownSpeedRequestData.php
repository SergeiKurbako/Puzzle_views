<?php

namespace Modules\Games\Games\Mazes\UilsonMaze\RequestDataSets;

use Avior\GameCore\RequestDataSets\RequestDataSet;

class DownSpeedRequestData extends RequestDataSet
{
    
}
