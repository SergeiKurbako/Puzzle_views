<?php

return [
    'name' => 'Games'
];
