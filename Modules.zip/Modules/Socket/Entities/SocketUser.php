<?php

namespace Modules\Socket\Entities;

use Illuminate\Database\Eloquent\Model;

class SocketUser extends Model
{
    protected $fillable = [];
}
