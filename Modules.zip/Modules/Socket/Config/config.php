<?php

return [
    'name' => 'Socket'
];
