<?php

return [
    'name' => 'AdminDashboard'
];
