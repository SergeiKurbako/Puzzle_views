<?php

return [
    'name' => 'GameFrame'
];
