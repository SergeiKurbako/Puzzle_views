@extends('userdashboard::layouts.master')

@section('content')
    <div class="container">
        <hr>
        
    </div>
    <div class="main">
            <div class="main__wrapper">

                <div class="main__name-page">
                    <h1>Регистрация</h1>
                </div>

                <div class="main__table">

                    <div class="main__table--table" style="margin-bottom: 20px;">
                        <p>Ожидайте подтверждения регистрации</p>  
                    </div>
                </div>
            </div>
        </div>

@endsection
